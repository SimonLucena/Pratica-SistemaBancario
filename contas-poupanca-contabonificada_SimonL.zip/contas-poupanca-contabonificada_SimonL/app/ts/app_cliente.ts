let clienteController = new ClienteController();

clienteController.listar();

const cc1 = new Conta('1', 100);
const pc1 = new Poupanca('2', 100);
const cbc1 = new ContaBonificada('3', 0);
const cl1 = new Cliente('Teste', '00887473440', c1);
const clinte = new Clientes();

console.log('Conta: ' + c1.saldo);

pc1.atualizarSaldoAniversario();
console.log('Poupanca: ' + pc1.saldo);

cbc1.creditar(100);
console.log('Conta Bonificada: ' + cbc1.saldo);


clinte.inserir(cl1);
console.log('Clientes: '+clinte.pesquisar('05206246450').nome);
class ClienteController {

    private inputNome: HTMLInputElement;
    private inputCPF: HTMLInputElement;
    private inputNumero: HTMLInputElement;
    private inputSaldo: HTMLInputElement;

    private contas: Contas;
    private clientes: Clientes;

    constructor() {
        this.inputNome =
            <HTMLInputElement>document.querySelector("#nome");
        this.inputCPF =
            <HTMLInputElement>document.querySelector("#cpf");
        this.inputNumero =
            <HTMLInputElement>document.querySelector("#conta");
        this.inputSaldo =
            <HTMLInputElement>document.querySelector("#saldo");
        this.contas = new Contas();
        this.clientes = new Clientes();
    }

    inserir(evento: Event) {
        evento.preventDefault();
        let novaConta = new Conta(this.inputNumero.value,
            parseFloat(this.inputSaldo.value));

        let novoCliente = new Cliente(this.inputNome.value, this.inputCPF.value, novaConta);

        this.clientes.inserir(novoCliente);
        this.contas.inserir(novaConta);
        this.inserirContaNoHTML(novoCliente);
    }

    listar() {
        this.clientes.listar().forEach(
            clinte => {
                this.inserirContaNoHTML(clinte);
            }
        );
    }

    inserirContaNoHTML(cliente: Cliente) {
        const elementoT = document.getElementById('TabelaCliente') as HTMLTableElement;
        const row = elementoT.insertRow(-1);
        const elementoNome = document.createElement('td');
        const elementoCPF = document.createElement('td');
        const elementoNumero = document.createElement('td');
        const elementoSaldo = document.createElement('td');

        elementoNome.textContent = cliente.nome.toString();
        elementoCPF.textContent = cliente.cpf.toString();
        elementoNumero.textContent = cliente.conta.numero.toString();
        elementoSaldo.textContent = cliente.conta.saldo.toString();
        row.appendChild(elementoNome);
        row.appendChild(elementoCPF);
        row.appendChild(elementoNumero);
        row.appendChild(elementoSaldo);
        const botaoApagar = document.createElement('button');
        botaoApagar.textContent = 'X';
        botaoApagar.addEventListener('click',
            (event) => {
                console.log('removendo cliente ' + cliente.toString());
                this.clientes.remover(cliente.cpf);
                (<Element>event.target).parentElement.remove();
            }
            );
        row.appendChild(botaoApagar);
    }


}

class ClienteController {
    inputNome;
    inputCPF;
    inputNumero;
    inputSaldo;
    contas;
    clientes;
    constructor() {
        this.inputNome =
            document.querySelector("#nome");
        this.inputCPF =
            document.querySelector("#cpf");
        this.inputNumero =
            document.querySelector("#conta");
        this.inputSaldo =
            document.querySelector("#saldo");
        this.contas = new Contas();
        this.clientes = new Clientes();
    }
    inserir(evento) {
        evento.preventDefault();
        let novaConta = new Conta(this.inputNumero.value, parseFloat(this.inputSaldo.value));
        let novoCliente = new Cliente(this.inputNome.value, this.inputCPF.value, novaConta);
        this.clientes.inserir(novoCliente);
        this.contas.inserir(novaConta);
        this.inserirContaNoHTML(novoCliente);
    }
    listar() {
        this.clientes.listar().forEach(clinte => {
            this.inserirContaNoHTML(clinte);
        });
    }
    inserirContaNoHTML(cliente) {
        const elementoT = document.getElementById('TabelaCliente');
        const row = elementoT.insertRow(-1);
        const elementoNome = document.createElement('td');
        const elementoCPF = document.createElement('td');
        const elementoNumero = document.createElement('td');
        const elementoSaldo = document.createElement('td');
        elementoNome.textContent = cliente.nome.toString();
        elementoCPF.textContent = cliente.cpf.toString();
        elementoNumero.textContent = cliente.conta.numero.toString();
        elementoSaldo.textContent = cliente.conta.saldo.toString();
        row.appendChild(elementoNome);
        row.appendChild(elementoCPF);
        row.appendChild(elementoNumero);
        row.appendChild(elementoSaldo);
        const botaoApagar = document.createElement('button');
        botaoApagar.textContent = 'X';
        botaoApagar.addEventListener('click', (event) => {
            console.log('removendo cliente ' + cliente.toString());
            this.clientes.remover(cliente.cpf);
            event.target.parentElement.remove();
        });
        row.appendChild(botaoApagar);
    }
}
